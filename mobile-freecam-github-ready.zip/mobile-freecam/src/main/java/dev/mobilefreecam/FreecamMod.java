package dev.mobilefreecam;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class FreecamMod implements ClientModInitializer {
    public static final String MOD_ID = "mobilefreecam";
    public static FreecamConfig CONFIG = new FreecamConfig();
    public static KeyBinding TOGGLE;
    public static KeyBinding BOOST;

    @Override
    public void onInitializeClient() {
        CONFIG = FreecamConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        TOGGLE = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobilefreecam.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F6, category));
        BOOST = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobilefreecam.boost", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_CONTROL, category));

        // Toggle handling, safety checks, input swallowing (before vanilla input handling runs).
        ClientTickEvents.START_CLIENT_TICK.register(FreecamController::tick);

        // Always leave Freecam cleanly on join/disconnect.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> FreecamController.disable(client, null));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> FreecamController.disable(client, null));

        // Belt and braces: even if a click slips through, block every interaction while active.
        AttackBlockCallback.EVENT.register((p, w, hand, pos, dir) ->
                FreecamController.isActive() ? ActionResult.FAIL : ActionResult.PASS);
        AttackEntityCallback.EVENT.register((p, w, hand, entity, hit) ->
                FreecamController.isActive() ? ActionResult.FAIL : ActionResult.PASS);
        UseBlockCallback.EVENT.register((p, w, hand, hit) ->
                FreecamController.isActive() ? ActionResult.FAIL : ActionResult.PASS);
        UseEntityCallback.EVENT.register((p, w, hand, entity, hit) ->
                FreecamController.isActive() ? ActionResult.FAIL : ActionResult.PASS);
        UseItemCallback.EVENT.register((p, w, hand) ->
                FreecamController.isActive() ? ActionResult.FAIL : ActionResult.PASS);

        // "FREECAM" HUD indicator
        HudElementRegistry.addLast(Identifier.of(MOD_ID, "indicator"), (ctx, tickCounter) -> {
            if (!FreecamController.isActive() || !CONFIG.showIndicator) return;
            var tr = MinecraftClient.getInstance().textRenderer;
            String label = "FREECAM";
            int w = tr.getWidth(label);
            int px = (ctx.getScaledWindowWidth() - w) / 2;
            int py = 6;
            ctx.fill(px - 4, py - 3, px + w + 4, py + tr.fontHeight + 2, 0x99000000);
            ctx.drawTextWithShadow(tr, label, px, py, 0xFFFF5555);
        });

        // Touch-friendly settings: /freecam speed 15, /freecam boost 4 ...
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("freecam")
                        .then(ClientCommandManager.literal("speed")
                                .then(ClientCommandManager.argument("blocksPerSecond", DoubleArgumentType.doubleArg(0.5, 200))
                                        .executes(ctx -> {
                                            CONFIG.speed = DoubleArgumentType.getDouble(ctx, "blocksPerSecond");
                                            CONFIG.save();
                                            ctx.getSource().sendFeedback(Text.literal("Freecam speed: " + CONFIG.speed + " blocks/s"));
                                            return 1;
                                        })))
                        .then(ClientCommandManager.literal("boost")
                                .then(ClientCommandManager.argument("multiplier", DoubleArgumentType.doubleArg(1, 20))
                                        .executes(ctx -> {
                                            CONFIG.boostMultiplier = DoubleArgumentType.getDouble(ctx, "multiplier");
                                            CONFIG.save();
                                            ctx.getSource().sendFeedback(Text.literal("Freecam boost: x" + CONFIG.boostMultiplier));
                                            return 1;
                                        })))
                        .then(ClientCommandManager.literal("allowserver")
                                .executes(ctx -> {
                                    ServerInfo info = ctx.getSource().getClient().getCurrentServerEntry();
                                    if (info == null) {
                                        ctx.getSource().sendFeedback(Text.literal("Not on a multiplayer server."));
                                        return 0;
                                    }
                                    if (!CONFIG.serverAllowlist.contains(info.address)) CONFIG.serverAllowlist.add(info.address);
                                    CONFIG.save();
                                    ctx.getSource().sendFeedback(Text.literal(
                                            "Freecam allowed on " + info.address + ". Only do this if the server's rules permit client-side freecam."));
                                    return 1;
                                }))
                        .then(ClientCommandManager.literal("reload")
                                .executes(ctx -> {
                                    CONFIG = FreecamConfig.load();
                                    ctx.getSource().sendFeedback(Text.literal("Freecam config reloaded."));
                                    return 1;
                                }))));
    }
}
