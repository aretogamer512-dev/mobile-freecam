package dev.mobilefreecam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

/**
 * All Freecam state and logic. The real player is never moved: we swap its Input for an empty
 * one, swallow look/interaction input, and only ever change where the *render camera* sits.
 */
public final class FreecamController {
    private static boolean active;

    // Camera state (render-only)
    private static double x, y, z;
    private static double vx, vy, vz;
    private static float yaw, pitch;
    private static long lastNanos;

    // Session guards
    private static ClientPlayerEntity player;
    private static ClientWorld world;
    private static Input originalInput;
    private static Input dummyInput;

    private FreecamController() {}

    public static boolean isActive() { return active; }
    public static double camX() { return x; }
    public static double camY() { return y; }
    public static double camZ() { return z; }
    public static float camYaw() { return yaw; }
    public static float camPitch() { return pitch; }

    // ---------------------------------------------------------------- lifecycle

    public static void toggle(MinecraftClient mc) {
        if (active) disable(mc, "Freecam off");
        else enable(mc);
    }

    private static void enable(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || !p.isAlive()) return;
        if (!permitted(mc)) {
            p.sendMessage(Text.literal("Freecam is disabled on this server (see mobilefreecam.json / /freecam allowserver)."), true);
            return;
        }
        player = p;
        world = mc.world;
        x = p.getX();
        y = p.getEyeY();
        z = p.getZ();
        yaw = p.getYaw();
        pitch = p.getPitch();
        vx = vy = vz = 0;
        lastNanos = System.nanoTime();

        // Real player gets an empty Input => it cannot walk, jump, sneak or sprint.
        originalInput = p.input;
        dummyInput = new Input() {};
        p.input = dummyInput;
        p.setSprinting(false);

        active = true;
        p.sendMessage(Text.literal("Freecam on"), true);
    }

    /** Safe to call at any time (disconnect, death, dimension change...). */
    public static void disable(MinecraftClient mc, String message) {
        if (!active) return;
        active = false;
        if (player != null && originalInput != null && player.input == dummyInput) {
            player.input = originalInput; // camera falls back to the real player instantly
        }
        player = null;
        world = null;
        originalInput = null;
        dummyInput = null;
        vx = vy = vz = 0;
        if (message != null && mc.player != null) {
            mc.player.sendMessage(Text.literal(message), true);
        }
    }

    // ---------------------------------------------------------------- per tick (20/s)

    public static void tick(MinecraftClient mc) {
        while (FreecamMod.TOGGLE.wasPressed()) toggle(mc);
        if (!active) return;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || p != player || mc.world != world
                || !p.isAlive() || p.getHealth() <= 0f) {
            disable(mc, null); // disconnect / dimension change / respawn / death
            return;
        }
        if (FreecamMod.CONFIG.disableOnDamage && p.hurtTime > 0) {
            disable(mc, "Freecam ended: you took damage");
            return;
        }
        if (!permitted(mc)) {
            disable(mc, "Freecam is not allowed here");
            return;
        }

        p.input = dummyInput; // keep the body frozen even if something swaps the input
        p.setSprinting(false);

        // Swallow every interaction key so nothing reaches the vanilla handlers.
        GameOptions o = mc.options;
        KeyBinding[] swallowed = {o.attackKey, o.useKey, o.pickItemKey, o.inventoryKey, o.dropKey, o.swapHandsKey};
        for (KeyBinding kb : swallowed) {
            kb.setPressed(false);
            while (kb.wasPressed()) { /* discard */ }
        }
        // No container / inventory screens while detached.
        if (mc.currentScreen instanceof HandledScreen<?>) {
            mc.setScreen(null);
        }
    }

    // ---------------------------------------------------------------- per frame (smooth)

    /** Mouse/touch look, forwarded from EntityMixin. Same 0.15 factor as vanilla. */
    public static void rotate(double dx, double dy) {
        yaw += (float) (dx * 0.15);
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) (dy * 0.15)));
    }

    /** Called once per rendered frame by CameraMixin. */
    public static void updateFrame() {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1.0e9f, 0.1f);
        lastNanos = now;
        if (dt <= 0f || player == null) return;

        double f = 0, s = 0, u = 0;
        if (mc.currentScreen == null && mc.isWindowFocused()) {
            GameOptions o = mc.options;
            f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
            s = (o.rightKey.isPressed() ? 1 : 0) - (o.leftKey.isPressed() ? 1 : 0);
            u = (o.jumpKey.isPressed() ? 1 : 0) - (o.sneakKey.isPressed() ? 1 : 0);
        }

        // Horizontal movement follows yaw only (spectator-style); Space/Shift are world-vertical.
        double yr = Math.toRadians(yaw);
        double sin = Math.sin(yr), cos = Math.cos(yr);
        double wx = -sin * f - cos * s;
        double wz = cos * f - sin * s;
        double wy = u;
        double len = Math.sqrt(wx * wx + wy * wy + wz * wz);
        if (len > 1.0e-6) { wx /= len; wy /= len; wz /= len; }

        FreecamConfig cfg = FreecamMod.CONFIG;
        double speed = cfg.speed * (FreecamMod.BOOST.isPressed() ? cfg.boostMultiplier : 1.0);

        // Exponential smoothing toward the target velocity (frame-rate independent).
        double a = 1.0 - Math.exp(-cfg.acceleration * dt);
        vx += (wx * speed - vx) * a;
        vy += (wy * speed - vy) * a;
        vz += (wz * speed - vz) * a;

        x += vx * dt;
        y += vy * dt;
        z += vz * dt;

        // Keep the camera within maxDistance of the real player (chunks beyond render distance are empty).
        double ax = player.getX(), ay = player.getEyeY(), az = player.getZ();
        double dx = x - ax, dy = y - ay, dz = z - az;
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > cfg.maxDistance) {
            double k = cfg.maxDistance / d;
            x = ax + dx * k; y = ay + dy * k; z = az + dz * k;
            vx = vy = vz = 0;
        }
    }

    // ---------------------------------------------------------------- multiplayer policy

    public static boolean permitted(MinecraftClient mc) {
        FreecamConfig cfg = FreecamMod.CONFIG;
        if (mc.isInSingleplayer()) return true;
        if (!cfg.disableOnMultiplayer) return true;
        ServerInfo info = mc.getCurrentServerEntry();
        if (info == null || info.address == null) return false;
        for (String allowed : cfg.serverAllowlist) {
            if (allowed != null && allowed.equalsIgnoreCase(info.address)) return true;
        }
        return false;
    }
}
