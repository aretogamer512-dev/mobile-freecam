package dev.mobilefreecam.mixin;

import dev.mobilefreecam.FreecamController;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Mouse / touch look normally rotates the player. While Freecam is on, rotate the camera instead. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void mobilefreecam$look(double dx, double dy, CallbackInfo ci) {
        if (FreecamController.isActive() && (Object) this == MinecraftClient.getInstance().player) {
            FreecamController.rotate(dx, dy);
            ci.cancel(); // real player rotation stays untouched
        }
    }
}
