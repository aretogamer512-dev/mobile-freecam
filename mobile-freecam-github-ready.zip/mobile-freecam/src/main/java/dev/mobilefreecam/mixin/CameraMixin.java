package dev.mobilefreecam.mixin;

import dev.mobilefreecam.FreecamController;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** After vanilla positions the camera on the player, overwrite it while Freecam is active. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow private boolean thirdPerson;

    @Inject(method = "update", at = @At("TAIL"))
    private void mobilefreecam$update(CallbackInfo ci) {
        if (!FreecamController.isActive()) return;
        FreecamController.updateFrame();
        this.setPos(FreecamController.camX(), FreecamController.camY(), FreecamController.camZ());
        this.setRotation(FreecamController.camYaw(), FreecamController.camPitch());
        // "Third person" makes the game draw your real body and hide the first-person hand.
        this.thirdPerson = true;
    }
}
