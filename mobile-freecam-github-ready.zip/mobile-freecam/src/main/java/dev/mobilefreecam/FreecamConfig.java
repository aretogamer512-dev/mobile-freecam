package dev.mobilefreecam;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Stored at <game dir>/config/mobilefreecam.json */
public final class FreecamConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Base camera speed in blocks per second. */
    public double speed = 10.0;
    /** Multiplier applied while the boost key is held. */
    public double boostMultiplier = 3.0;
    /** Higher = snappier acceleration/deceleration. ~10 feels smooth, ~25 feels tight. */
    public double acceleration = 10.0;
    /** How far the camera may drift from the real player (blocks). */
    public double maxDistance = 128.0;
    /** If true, Freecam only works in singleplayer or on servers in serverAllowlist. */
    public boolean disableOnMultiplayer = true;
    /** Server addresses (as shown in your server list) where you have confirmed Freecam is allowed. */
    public List<String> serverAllowlist = new ArrayList<>();
    /** End Freecam when the real player takes damage. */
    public boolean disableOnDamage = true;
    public boolean showIndicator = true;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("mobilefreecam.json");
    }

    public static FreecamConfig load() {
        FreecamConfig cfg = null;
        try {
            if (Files.exists(path())) {
                cfg = GSON.fromJson(Files.readString(path()), FreecamConfig.class);
            }
        } catch (Exception e) {
            System.err.println("[MobileFreecam] Could not read config, using defaults: " + e);
        }
        if (cfg == null) cfg = new FreecamConfig();
        cfg.sanitize();
        cfg.save();
        return cfg;
    }

    public void sanitize() {
        speed = clamp(speed, 0.5, 200);
        boostMultiplier = clamp(boostMultiplier, 1, 20);
        acceleration = clamp(acceleration, 1, 100);
        maxDistance = clamp(maxDistance, 8, 1024);
        if (serverAllowlist == null) serverAllowlist = new ArrayList<>();
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[MobileFreecam] Could not save config: " + e);
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v));
    }
}
