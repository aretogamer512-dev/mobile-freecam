# Mobile Freecam — Minecraft 1.21.11

Client-side Fabric Freecam project for Minecraft Java Edition 1.21.11.

## Build on GitHub

1. Create a new GitHub repository.
2. Upload all files from this project (including `.github/workflows/build.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build Mobile Freecam**.
5. Press **Run workflow**, or push a commit to start it automatically.
6. When the workflow finishes, open the workflow run and download the artifact named **mobile-freecam-1.21.11**.
7. The artifact contains `mobile-freecam-1.0.0.jar`.

The workflow uses Java 21 and Gradle 9.2.0. Fabric Loom 1.14 requires Gradle 9.2 for this project.

## Mojo Launcher

Install the resulting JAR into the `mods` folder of a Minecraft 1.21.11 Fabric instance, together with a compatible Fabric API build. Make sure the server permits client-side Freecam before using it in multiplayer.

## Controls

- F6: Toggle Freecam
- Left Ctrl: Temporary speed boost
- `/freecam speed <number>`: Set camera speed
- `/freecam boost <multiplier>`: Set boost multiplier
- `/freecam allowserver`: Allow the current multiplayer server in the mod's local allowlist (only where permitted by server rules)
- `/freecam reload`: Reload configuration

## Notes

This project does not implement packet manipulation, anti-cheat bypasses, or hidden movement. The real player is kept stationary while the camera is detached.
